import React from 'react';
import '../../App.css'

import Footer from '../Footer';

import Hospitality from '../Hospitality'
import Navbar2 from '../Navbar2';



function Hosppage(){
    return(
         <>
    <Navbar2/>
             <Hospitality />
             
             
                         
             
            
        

        
         
        
      
         </>
        
    );
}
export default Hosppage;