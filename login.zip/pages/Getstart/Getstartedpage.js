import React from 'react';
import '../../../App.css'

import Footer from '../../Footer';

import Getstarted from './Getstarted';
import Navbar2 from '../../Navbar2';



function Getstartedpage({setLoginUser}){
    return(
         <>
             <Navbar2/>
             <Getstarted/>
             <Footer/>
             
                         
             
            
        

        
         
        
      
         </>
        
    );
}
export default Getstartedpage;